package uz.developer.sharedpreferences.models

data class User(var uname: String, var uphone:String)
